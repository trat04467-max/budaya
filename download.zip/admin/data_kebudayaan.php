<?php 
  include "../koneksi.php";
  include "admin_panel.php";

  $admin_id = $_SESSION["role_id"];

  // tampilkan catatan
  $sql = $db->prepare("SELECT * FROM kebudayan WHERE admin_id = ? ORDER BY tanggal_dibuat DESC");
  $sql->bind_param("i",$admin_id);
  $sql->execute();
  $result = $sql->get_result();

  if (isset($_GET['hapus'])) {
    $id = $_GET['hapus']; 

    $sql_hapus = "DELETE FROM kebudayan WHERE id = $id";
    if ($db->query($sql_hapus)) {
        echo "<script>alert('Catatan berhasil dihapus!'); window.location.href='data_kebudayaan.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus catatan!');</script>";
    }
  }
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Budaya Sulawesi Utara</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background: #f5f7fa;
      color: #333;
    }

    .main {
      padding: 20px;
      max-width: 1200px;
      margin: auto;
    }

    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 20px;
    }

    .card {
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 16px rgba(0,0,0,0.15);
    }

    .note-img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 8px;
      margin-bottom: 12px;
    }

    .note-title {
      font-size: 1.2rem;
      font-weight: bold;
      margin-bottom: 10px;
      color: #2c3e50;
    }

    .note-content {
      font-size: 0.95rem;
      line-height: 1.5;
      margin-bottom: 15px;
      color: #555;
    }

    .note-date {
      font-size: 0.85rem;
      color: #777;
      display: block;
      margin-bottom: 15px;
    }

    .note-actions {
      display: flex;
      gap: 10px;
    }

    .btn {
      padding: 8px 12px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 0.9rem;
      transition: background 0.2s ease;
    }

    .btn.edit {
      background: #3498db;
      color: #fff;
    }
    .btn.edit:hover {
      background: #2980b9;
    }

    .btn.delete {
      background: #e74c3c;
      color: #fff;
    }
    .btn.delete:hover {
      background: #c0392b;
    }

    @media (max-width: 600px) {
      .note-title {
        font-size: 1rem;
      }
      .note-content {
        font-size: 0.85rem;
      }
    }
  </style>
</head>
<body>
  <div class="main">
    <h1 style="text-align:center; margin-bottom:20px;">📜 Catatan Budaya Sulawesi Utara</h1>

    <div class="cards">
      <?php while ($kebudayan = $result->fetch_assoc()): ?>
        <div class="card note-card">
          <?php if (!empty($kebudayan['gambar'])): ?>
            <img src="../uploads/<?= htmlspecialchars($kebudayan['gambar']); ?>" alt="Gambar Budaya" class="note-img">
          <?php endif; ?>

          <?php
            $max_kata = 10;
            $judul = htmlspecialchars($kebudayan['judul']);
            $judul_array = explode(' ', $judul);
            $judul_terbatas = implode(' ', array_slice($judul_array, 0, $max_kata));

            $max_kata2 = 50;
            $isi = htmlspecialchars($kebudayan['deskripsi']);
            $isi_array = explode(' ', $isi);
            $isi_terbatas = implode(' ', array_slice($isi_array, 0, $max_kata2));
          ?>
          <h2 class="note-title"><?= $judul_terbatas ?><?= count($judul_array) > $max_kata ? '...' : '' ?></h2>
          <p class="note-content"><?= $isi_terbatas ?><?= count($isi_array) > $max_kata2 ? '...' : '' ?></p>
          <span class="note-date">📅 <?= $kebudayan['tanggal_dibuat'] ?></span>

          <div class="note-actions">
            <button class="btn edit" onclick="window.location.href='edit_kebudayaan.php?id=<?= $kebudayan['id']; ?>'">✏️ Edit</button>
            <button class="btn delete" onclick="if(confirm('Yakin ingin menghapus catatan ini?')) window.location.href='?hapus=<?= $kebudayan['id']; ?>'">🗑️ Hapus</button>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</body>
</html>
