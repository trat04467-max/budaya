<?php 
include "../koneksi.php";
include "admin_panel.php";

$kebudayan_id = $_GET["id"];

// Ambil data lama
$sql = $db->prepare("SELECT * FROM kebudayan WHERE id = ?");
$sql->bind_param("i", $kebudayan_id);
$sql->execute();
$result = $sql->get_result();
$kebudayan = $result->fetch_assoc();

if (!$kebudayan) {
    echo "<script>alert('Catatan tidak ditemukan!'); window.location.href='dashboard_admin.php';</script>";
    exit();
}

// Update data
if (isset($_POST["update_catatan"])) {
    $judul = $_POST["judul"];
    $deskripsi = $_POST["deskripsi"];

    if (!empty($_FILES["gambar"]["name"])) {
        $targetDir = "../uploads/";
        $fileName = basename($_FILES["gambar"]["name"]);
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFilePath)) {
            $update_sql = $db->prepare("UPDATE kebudayan SET judul = ?, deskripsi = ?, gambar = ? WHERE id = ?");
            $update_sql->bind_param("sssi", $judul, $deskripsi, $fileName, $kebudayan_id);
        }
    } else {
        $update_sql = $db->prepare("UPDATE kebudayan SET judul = ?, deskripsi = ? WHERE id = ?");
        $update_sql->bind_param("ssi", $judul, $deskripsi, $kebudayan_id);
    }

    if ($update_sql->execute()) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location.href='dashboard_admin.php';</script>";
    } else {
        echo "Gagal memperbarui data!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Catatan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .container {
      max-width: 700px;
      margin-top: 40px;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .card-header {
      background: #0d6efd;
      color: white;
      font-weight: bold;
      font-size: 18px;
    }
    .preview img {
      max-width: 200px;
      border-radius: 8px;
      margin-top: 10px;
    }
    .btn-group {
      margin-top: 20px;
      display: flex;
      gap: 10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="card">
    <div class="card-header">
      ✏ Edit Catatan
    </div>
    <div class="card-body">
      <form method="post" enctype="multipart/form-data">
        
        <div class="mb-3">
          <label class="form-label">Judul</label>
          <input type="text" name="judul" class="form-control" 
                 value="<?= htmlspecialchars($kebudayan['judul']) ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Deskripsi</label>
          <textarea name="deskripsi" class="form-control" rows="5"><?= htmlspecialchars($kebudayan['deskripsi']) ?></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Upload Gambar Baru</label>
          <input type="file" name="gambar" class="form-control">
        </div>

        <?php if (!empty($kebudayan['gambar'])): ?>
          <div class="preview">
            <p class="fw-bold">Gambar Lama:</p>
            <img src="../uploads/<?= htmlspecialchars($kebudayan['gambar']) ?>" alt="gambar lama">
          </div>
        <?php endif; ?>

        <div class="btn-group">
          <button type="submit" name="update_catatan" class="btn btn-primary">💾 Simpan</button>
          <a href="dashboard_admin.php" class="btn btn-secondary">⬅ Kembali</a>
        </div>

      </form>
    </div>
  </div>
</div>

</body>
</html>
