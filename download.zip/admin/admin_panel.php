<?php 
session_start();

if(isset($_GET ['logout'])){
            session_unset();
            session_destroy();
            header("location: ../index.php");
            exit;
}

if(!isset($_SESSION["role_id"]) || $_SESSION["role_id"]!=1){
    echo "<script> window.location.href='../index.php' </script>";
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6f9;
    }
    /* Sidebar */
    .sidebar {
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      width: 250px;
      background: #1e1e2f;
      color: white;
      transition: 0.3s;
      padding-top: 60px;
      z-index: 1000;
    }
    .sidebar h4 {
      color: #0d6efd;
      font-weight: bold;
    }
    .sidebar a {
      display: block;
      padding: 12px 20px;
      text-decoration: none;
      color: #adb5bd;
      transition: 0.3s;
      border-radius: 5px;
      margin: 5px 10px;
    }
    .sidebar a:hover {
      background: #0d6efd;
      color: #fff;
    }
    .sidebar .active {
      background: #0d6efd;
      color: white;
    }
    /* Tombol close */
    .sidebar .close-btn {
      position: absolute;
      top: 15px;
      right: 15px;
      font-size: 22px;
      cursor: pointer;
      display: none;
      color: #fff;
    }
    /* Content */
    .content {
      margin-left: 250px;
      padding: 20px;
      transition: 0.3s;
    }
    /* Responsive */
    @media (max-width: 768px) {
      .sidebar {
        left: -250px;
      }
      .sidebar.active {
        left: 0;
      }
      .sidebar .close-btn {
        display: block;
      }
      .content {
        margin-left: 0;
      }
    }
    /* Navbar toggle */
    .toggle-btn {
      background: #0d6efd;
      border: none;
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      font-size: 18px;
    }
    /* Card styling */
    .card {
      border: none;
      border-radius: 12px;
      transition: 0.3s;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    .card-title {
      font-weight: 600;
      color: #495057;
    }
    .display-6 {
      color: #0d6efd;
      font-weight: bold;
    }
    .table thead {
      background: #0d6efd;
      color: white;
    }
    .table tbody tr:hover {
      background: #f1f3f5;
    }
  </style>
</head>
<body>
     <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <span class="close-btn" id="closeBtn">&times;</span>
    <h4 class="text-center mb-4"><?php echo $_SESSION["username"]; ?></h4>
    <a href="dashboard_admin.php" >Dashboard</a>
    <a href="data_kebudayaan.php">Data Kebudayaan</a>
    <a href="tambah_kebudayaan.php">Tambah Kebudayaan</a>
    <a href="pengguna.php">Pengguna</a>
    <a href="?logout=<?= $_SESSION['user_id']; ?>" onclick="return confirm('Apakah Anda yakin ingin keluar dari akun ini?')" style="color: var(--danger);">Logout</a>
  </div>

    <!-- Content -->
  <div class="content">
    <nav class="navbar navbar-light bg-white shadow-sm mb-4 rounded">
      <div class="container-fluid d-flex justify-content-between">
        <button class="toggle-btn" id="toggleBtn">☰</button>
        <span class="navbar-brand mb-0 h1 fw-bold">Dashboard Admin</span>
      </div>
    </nav>

    <script>
        const toggleBtn = document.getElementById('toggleBtn');
        const closeBtn = document.getElementById('closeBtn');
        const sidebar = document.getElementById('sidebar');

        toggleBtn.addEventListener('click', () => {
        sidebar.classList.add('active');
        });

        closeBtn.addEventListener('click', () => {
        sidebar.classList.remove('active');
        });
  </script>
</body>
</html>