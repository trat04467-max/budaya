<?php
include "../koneksi.php";
include "admin_panel.php";

// Hitung jumlah user
$sql = mysqli_query($db, "SELECT COUNT(*) AS total_user FROM users");
$row = mysqli_fetch_assoc($sql);
$total_user = $row["total_user"];

// Hitung jumlah kebudayaan
$sql = mysqli_query($db, "SELECT COUNT(*) AS total_kebudayan FROM kebudayan");
$row = mysqli_fetch_assoc($sql);
$total_kebudayan = $row["total_kebudayan"];

// Ambil semua data kebudayaan
$data_kebudayaan = mysqli_query($db, "SELECT * FROM kebudayan ORDER BY tanggal_dibuat DESC");

  if (isset($_GET['hapus'])) {
    $id = $_GET['hapus']; 

    $sql_hapus = "DELETE FROM kebudayan WHERE id = $id";
    if ($db->query($sql_hapus)) {
        echo "<script>alert('Catatan berhasil dihapus!'); window.location.href='dashboard_admin.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus catatan!');</script>";
    }
  }

?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6f9;
    }
    .card {
      border: none;
      border-radius: 12px;
      transition: 0.3s;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    .card-title {
      font-weight: 600;
      color: #495057;
    }
    .display-6 {
      color: #0d6efd;
      font-weight: bold;
    }
    .table thead {
      background: #0d6efd;
      color: white;
    }
    .table tbody tr:hover {
      background: #f1f3f5;
    }
  </style>
</head>
<body>

<div class="container mt-4">

  <div class="row g-4">
    <div class="col-md-6 col-12">
      <div class="card shadow-sm p-3">
        <div class="card-body">
          <h5 class="card-title">Total Kebudayaan</h5>
          <p class="card-text display-6"><?php echo $total_kebudayan; ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-12">
      <div class="card shadow-sm p-3">
        <div class="card-body">
          <h5 class="card-title">Jumlah Pengguna</h5>
          <p class="card-text display-6"><?php echo $total_user; ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Tabel Data Kebudayaan -->
  <div class="card shadow-sm border-0 mt-5">
    <div class="card-header bg-primary text-white fw-bold">
      Data Kebudayaan
    </div>
    <div class="card-body table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Judul</th>
            <th>Kategori</th>
            <th>Tanggal</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          $no = 1;
          while ($row = mysqli_fetch_assoc($data_kebudayaan)): ?>
            <tr>
              <td><?php echo $no++; ?></td>
              <td><?php echo htmlspecialchars($row['judul']); ?></td>
              <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
              <td><?php echo $row['tanggal_dibuat']; ?></td>
              <td>
                <a href="edit_kebudayaan.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="?hapus=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

</body>
</html>
