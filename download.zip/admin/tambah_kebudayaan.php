<?php
include '../koneksi.php';
include "admin_panel.php";

$admin_role = $_SESSION["role_id"];

// Proses upload berita kebudayaan
if (isset($_POST['submit'])) {
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];

    // Upload gambar
    $targetDir = "../uploads/";
    $fileName = basename($_FILES["gambar"]["name"]);
    $targetFilePath = $targetDir . $fileName;

    if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFilePath)) {
        $sql = $db->prepare("INSERT INTO kebudayan (admin_id,judul, deskripsi, gambar) VALUES (?,?, ?, ?)");
        $sql->bind_param("isss",$admin_role, $judul, $deskripsi, $fileName);

        if ($sql->execute()) {
            echo "<script>alert('Berita berhasil ditambahkan!');</script>";
        } else {
            echo "<script>alert('Gagal menambahkan berita');</script>";
        }
    } else {
        echo "<script>alert('Upload gambar gagal');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Kebudayaan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f4f6f9;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .container-box {
      max-width: 700px;
      margin: 60px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #0d6efd;
      font-weight: bold;
      margin-bottom: 25px;
    }
    label {
      font-weight: 600;
      margin-bottom: 6px;
    }
    .form-control, .form-control-file {
      margin-bottom: 15px;
      border-radius: 8px;
      padding: 10px;
    }
    textarea.form-control {
      resize: vertical;
    }
    button[type="submit"] {
      background: #0d6efd;
      border: none;
      color: white;
      padding: 12px;
      width: 100%;
      font-weight: 600;
      border-radius: 8px;
      transition: 0.3s;
    }
    button[type="submit"]:hover {
      background: #084298;
    }
    .back-link {
      display: block;
      text-align: center;
      margin-top: 15px;
    }
  </style>
</head>
<body>

        <!-- Sidebar -->



  <div class="container-box">
    <h2>Tambah Kebudayaan Baru</h2>
    <form action="" method="POST" enctype="multipart/form-data">
      
      <div class="mb-3">
        <label for="judul">Judul Berita</label>
        <input type="text" id="judul" name="judul" class="form-control" placeholder="Masukkan judul kebudayaan" required>
      </div>

      <div class="mb-3">
        <label for="deskripsi">Deskripsi</label>
        <textarea id="deskripsi" name="deskripsi" class="form-control" rows="5" placeholder="Tulis deskripsi kebudayaan" required></textarea>
      </div>

      <div class="mb-3">
        <label for="gambar">Upload Gambar</label>
        <input type="file" id="gambar" name="gambar" class="form-control" accept="image/*" required>
      </div>

      <button type="submit" name="submit">Tambah Berita</button>
    </form>
  </div>
</body>
</html>
