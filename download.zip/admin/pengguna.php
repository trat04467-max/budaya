<?php
include "../koneksi.php";
include "admin_panel.php";

// Hapus user
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $sql = $db->prepare("DELETE FROM users WHERE id = ?");
    $sql->bind_param("i", $id);
    if ($sql->execute()) {
        echo "<script>alert('User berhasil dihapus!'); window.location.href='users.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus user!');</script>";
    }
}

// Update role_id
if (isset($_POST['update_role'])) {
    $id = intval($_POST['user_id']);
    $role_id = intval($_POST['role_id']);
    $sql = $db->prepare("UPDATE users SET role_id = ? WHERE id = ?");
    $sql->bind_param("ii", $role_id, $id);
    if ($sql->execute()) {
        echo "<script>alert('Role user berhasil diperbarui!'); window.location.href='pengguna.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui role!');</script>";
    }
}

// Ambil semua data users
$result = $db->query("SELECT * FROM users ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manajemen User</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f4f6f9;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .container-box {
      max-width: 1000px;
      margin: 40px auto;
      background: #fff;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 6px 16px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: 700;
      color: #0066cc;
    }
    table {
      border-radius: 10px;
      overflow: hidden;
    }
    th {
      background: #0066cc !important;
      color: #fff;
    }
    tr:hover td {
      background: #f1f9ff;
    }
    .btn {
      border-radius: 6px;
      font-weight: 500;
      padding: 6px 12px;
    }
    .btn.update {
      background-color: #28a745;
      color: #fff;
    }
    .btn.update:hover {
      background-color: #218838;
    }
    .btn.delete {
      background-color: #dc3545;
      color: #fff;
    }
    .btn.delete:hover {
      background-color: #c82333;
    }
    @media (max-width: 768px) {
      .container-box {
        padding: 15px;
      }
      table {
        font-size: 14px;
      }
      .btn {
        padding: 4px 8px;
        font-size: 13px;
      }
    }
  </style>
</head>
<body>
  <div class="container-box">
    <h2>📋 Manajemen User</h2>
    <div class="table-responsive">
      <table class="table table-bordered align-middle text-center">
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Role ID</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($user = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $user['id']; ?></td>
              <td><?= htmlspecialchars($user['username']); ?></td>
              <td>
                <form method="POST" class="d-flex justify-content-center gap-2">
                  <input type="hidden" name="user_id" value="<?= $user['id']; ?>">
                  <select name="role_id" class="form-select form-select-sm w-auto">
                    <option value="1" <?= $user['role_id'] == 1 ? 'selected' : '' ?>>Admin</option>
                    <option value="0" <?= $user['role_id'] == 0 ? 'selected' : '' ?>>User</option>
                  </select>
                  <button type="submit" name="update_role" class="btn update btn-sm">Update</button>
                </form>
              </td>
              <td>
                <button class="btn delete btn-sm" onclick="if(confirm('Yakin ingin hapus user ini?')) window.location.href='users.php?hapus=<?= $user['id']; ?>'">Hapus</button>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
