<?php
include "koneksi.php";

// Ambil semua data kebudayaan
$sql = $db->prepare("SELECT * FROM kebudayan ORDER BY id DESC");
$sql->execute();
$result = $sql->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kebudayaan Sulawesi Utara</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #333;
    }
    .navbar {
      background-color: #0066cc;
    }
    .navbar-brand, .nav-link {
      color: white !important;
    }
    .hero-section {
      background: linear-gradient(rgba(0, 102, 204, 0.7), rgba(0, 102, 204, 0.7)), 
                  url('https://kabarbintaro.com/wp-content/uploads/2021/06/sangihe-scaled.jpg');
      background-size: cover;
      background-position: center;
      color: white;
      padding: 100px 0;
      text-align: center;
    }
    .section-title {
      color: #0066cc;
      border-bottom: 2px solid #99ccff;
      padding-bottom: 10px;
      margin-bottom: 30px;
    }
    .card {
      border: none;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      transition: transform 0.3s;
      margin-bottom: 20px;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .card-img-top {
      height: 200px;
      object-fit: cover;
    }
    .footer {
      background-color: #0066cc;
      color: white;
      padding: 30px 0;
      margin-top: 50px;
    }

    .btn-login {
      display: inline-block;
      padding: 10px 20px;
      background-color: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      transition: 0.3s;
    }

    .btn-login:hover {
      background-color: #2980b9;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">Kebudayaan Nusantara</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Beranda</a></li>
        <li class="nav-item"><a class="nav-link" href="#sangihe">Suku Sangihe</a></li>
        <li class="nav-item"><a class="nav-link" href="#budaya">Budaya</a></li>
      </ul>
      <a href="login.php" class="btn-login">Login</a>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero-section">
  <div class="container">
    <h1 class="display-4">Kebudayaan Sulawesi Utara</h1>
    <p class="lead">Menjaga Tradisi untuk Generasi Mendatang</p>
  </div>
</section>

<!-- Tentang Suku Sangihe -->
<section id="sangihe" class="py-5 bg-light">
  <div class="container">
    <h2 class="section-title">Tentang Suku Sangihe</h2>
    <div class="row align-items-center">
      <!-- Kolom Gambar di Kiri -->
      <div class="col-md-4 mb-3">
        <img src="https://kabarbintaro.com/wp-content/uploads/2021/06/sangihe-scaled.jpg" 
             alt="Pulau Sangihe" 
             class="img-fluid rounded shadow">
      </div>
      <!-- Kolom Teks di Kanan -->
      <div class="col-md-8">
        <p>
          Suku Sangihe adalah salah satu suku yang mendiami Kepulauan Sangihe, sebuah gugusan pulau yang berada di bagian paling utara Provinsi Sulawesi Utara dan berbatasan langsung dengan Filipina. Pulau terbesar di kepulauan ini adalah Pulau Sangihe Besar dengan pusat pemerintahan di Tahuna.
        </p>
        <p>
          Letaknya yang strategis menjadikan Sangihe sebagai pintu gerbang Indonesia di bagian utara, sekaligus wilayah yang mendapat pengaruh budaya dari luar, khususnya Filipina. Kondisi alamnya dikelilingi oleh laut yang kaya hasil tangkapan, sehingga sebagian besar masyarakat Sangihe berprofesi sebagai nelayan.
        </p>
      </div>
    </div>
  </div>
</section>



<!-- Konten Budaya -->
<section id="budaya" class="py-5">
  <div class="container">
    <h2 class="section-title">Daftar Kebudayaan</h2>
    <div class="row">
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="col-md-4">
          <div class="card">
            <?php if (!empty($row['gambar'])): ?>
              <img src="./uploads/<?= htmlspecialchars($row['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($row['judul']) ?>">
            <?php else: ?>
              <img src="https://via.placeholder.com/400x200?text=No+Image" class="card-img-top" alt="No Image">
            <?php endif; ?>
            
            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($row['judul']) ?></h5>
              <p class="card-text"><?= htmlspecialchars(substr($row['deskripsi'], 0, 300)) ?></p>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>
<!-- Footer -->
<footer class="footer text-center">
  <div class="container">
    <p>&copy; <?= date("Y") ?> Kebudayaan Sulawesi Utara | Dibuat oleh tania</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
