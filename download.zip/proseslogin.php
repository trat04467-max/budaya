<?php 
session_start();

include "koneksi.php";

if(isset($_POST["tekan"])){
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = $db->prepare("SELECT id, password,username,role_id FROM users WHERE username = ?");
    $sql->bind_param("s",$username);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Verifikasi password dengan password_verify
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role_id'] = $row['role_id'];
            $_SESSION['username'] = $row['username'];

            if ($row['role_id'] == 1) {
                header("location: admin/dashboard_admin.php");
            } elseif ($row['role_id'] == 0) {
                header("location: index.php");
                exit;
                
            }
            exit();
        } else {
            echo "<script>alert('Password atau nama salah!'); window.location='index.php';</script>";
            exit();
          
        }
    } else {
        header("location: index.php");
        exit();
    }
}



?>