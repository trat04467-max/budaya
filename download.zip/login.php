<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - Kebudayaan Sulut</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .login-container {
      max-width: 400px;
      margin: 80px auto;
      padding: 30px;
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .btn-primary {
      background-color: #0066cc;
      border-color: #0066cc;
    }
    .error {
      display: none;
      font-size: 0.85rem;
      color: red;
    }
    footer {
      margin-top: auto;
      background-color: #0066cc;
      color: white;
      padding: 15px 0;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #0066cc;">
    <div class="container">
      <a class="navbar-brand" href="index.php">Kebudayaan Sulut</a>
    </div>
  </nav>

  <!-- Form Login -->
  <div class="login-container">
    <h2 class="text-center mb-3">Login</h2>
    <p class="text-center text-muted">Masuk untuk melanjutkan ke dashboard.</p>
    <hr>
    
    <form action="proseslogin.php" method="POST" onsubmit="handleSubmit(event)">
      <div class="mb-3">
        <label for="username" class="form-label">Masukkan Nama</label>
        <input class="form-control" type="text" id="username" name="username" placeholder="nama" autocomplete="username" required />
        <div class="error" id="userErr">Nama minimal 3 karakter.</div>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">Masukkan Password</label>
        <div class="input-group">
          <input class="form-control" type="password" id="password" name="password" placeholder="password" autocomplete="current-password" required />
          <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">👁</button>
        </div>
        <div class="error" id="passErr">Password minimal 6 karakter.</div>
      </div>

      <button class="btn btn-primary w-100" type="submit" name="tekan" id="submitBtn">Login</button>
    </form>

  </div>

  <!-- Footer -->
  <footer class="text-center">
    <div class="container">
      <p class="mb-0">&copy; 2025 Kebudayaan Sulut | Dibuat oleh tani</p>
    </div>
  </footer>

  <script>
    function togglePassword(){
      const input = document.getElementById('password');
      input.type = input.type === 'password' ? 'text' : 'password';
    }
  </script>
</body>
</html>
