<?php 

$host = "sql102.infinityfree.com";
$user = "if0_40032626";
$pass = "kDlofFUeumA";
$db_name ="if0_40032626_kebudayaan_web";

$db = new mysqli($host,$user,$pass,$db_name);


?>